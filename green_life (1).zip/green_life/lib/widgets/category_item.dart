import 'package:app/screens/info_palant_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// هذا الكلاس مسؤل عن تنسيق هذه البيانات
class CategoryItem extends StatelessWidget {
  final String id;
  final String title;
  final String imageURL;
  final String information;
  final String price;

  CategoryItem(
      this.id, this.title, this.imageURL, this.information, this.price);
  // void selectCategory(BuildContext ctx) {
  //   Navigator.of(ctx).pushNamed(CategoryMeallScreen.routeName);
  // }
  void selectPlant(BuildContext ctx) {
    Navigator.of(ctx).pushNamed(InfoPlantScrren.routeinfoplant, arguments: {
      'id': id,
      'title': title,
      'imageURL': imageURL,
      'information': information,
      'price': price
    });
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: () {
          selectPlant(context);
        },
        child: Container(
          padding: EdgeInsets.all(15),
          child: Text(title),
          decoration: BoxDecoration(
            //color: color,
            color: Colors.amber,
          ),
        ));
  }
}
