import 'package:flutter/material.dart';

class Plant {
  final String id;
  final String title;
  final String imageURL;
  final String information;
  final String price;

  const Plant({
    required this.id,
    required this.title,
    required this.price,
    required this.information,
    required this.imageURL,
  });
}
