import 'package:flutter/material.dart';

import 'models/plantM.dart';

const DUMMY_PLANT = const [
  Plant(
    id: 'p1',
    title: 'Peperomia',
    imageURL:
        'https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1603654968-il_570xN.2485154742_kpa5.jpg?crop=0.856xw:0.955xh;0.0263xw,0.0274xh&resize=768:*',
    information:
        'These colorful plants grow great indoors. They also hold water in their stems and leaves, making them drought tolerant. When watering, make sure not to over water and check to see if the soil is completely dry in between watering sessions',
    price: '3.5',
  ),
  Plant(
    id: 'p2',
    title: 'Asparagus Fern',
    imageURL:
        'https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1554477330-beautiful-asparagus-fern-plant-in-a-basket-royalty-free-image-972247932-1546889240.jpg?crop=0.547xw:0.361xh;0.393xw,0.317xh&resize=768:*',
    information:
        'This fluffy plant tolerates a lot more abuse than other ferns — thanks to the fact that its technically not a fern. Asparagus setaceus adapts to both bright spots and darker corners. Keep the soil moist and it will thrive',
    price: '2.5',
  ),
  Plant(
    id: 'p3',
    title: 'Peace Lily',
    imageURL:
        'https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1554477330-beautiful-asparagus-fern-plant-in-a-basket-royalty-free-image-972247932-1546889240.jpg?crop=0.547xw:0.361xh;0.393xw,0.317xh&resize=768:*',
    information:
        'If you are prone to overwatering, try Spathiphyllum. Peace lilies can "almost grow in a fish tank,-Fried says. With enough light, theyll also produce their spade-shaped flowers throughout the year.',
    price: '3',
  ),
  Plant(
    id: 'p4',
    title: 'Peace Lily',
    imageURL:
        'https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1646681626-51MhStXDBAL._SL500_.jpg?crop=1xw:0.994xh;center,top&resize=768:*',
    information:
        'Prayer plants produce foliage pretty enough to outshine a bouquet, and you do not need a botany degree to maintain one. For the best display, keep the plant moist (not drenched) and avoid bright light',
    price: '4',
  ),
];
