import 'package:badges/badges.dart';

import '../widgets/category_item.dart';
import 'package:flutter/material.dart';
import 'package:app/dummy_data.dart';

class CategoriesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "category",
          style: Theme.of(context).textTheme.headline1,
        ),
        actions: [
          Center(
            child: Badge(
              badgeContent: Text(
                '0',
                style: TextStyle(color: Colors.white),
              ),
              animationDuration: Duration(milliseconds: 300),
              child: Icon(Icons.shopping_bag_outlined),
            ),
          ),
          SizedBox(width: 20.0),
        ],
      ),
      body: GridView(
        padding: const EdgeInsets.all(25),
        children: DUMMY_PLANT
            .map(
              (catData) => CategoryItem(
                //بهذه الصورة احنا ممرنا البيانات
                catData.id,
                catData.title,
                catData.imageURL,
                catData.information,
                catData.price,
              ),
            )
            .toList(),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 200,
          childAspectRatio: 3 / 2,
          crossAxisSpacing: 20,
          mainAxisSpacing: 20,
        ),
      ),
    );
  }
}
