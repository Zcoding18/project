import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class InfoPlantScrren extends StatefulWidget {
  static const routeinfoplant = 'plant_info';

  @override
  State<InfoPlantScrren> createState() => _InfoPlantScrrenState();
}

class _InfoPlantScrrenState extends State<InfoPlantScrren> {
  @override
  Widget build(BuildContext context) {
    final routeArgs =
        ModalRoute.of(context)!.settings.arguments as Map<String, String>;
    final plantId = routeArgs['id'];
    final plantTitle = routeArgs['title'];
    final plantImageURL = routeArgs['imageURL'];
    final plantInformation = routeArgs['information'];
    final plantPrice = routeArgs['price'];
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              children: [
                ClipRRect(
                  //نعطي شكل دائري من فوق
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    topRight: Radius.circular(15),
                  ),
                  child: Image.network(
                    '$plantImageURL',
                    height: 300,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    //mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Row(
                        children: [
                          Container(
                            margin: EdgeInsets.only(bottom: 10, top: 10),
                            child: Text(
                              '$plantTitle',
                              style: TextStyle(
                                fontSize: 20,
                                color: Colors.green[900],
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Container(
                            margin: EdgeInsets.only(bottom: 10, top: 10),
                            child: Text(
                              '$plantPrice OMR',
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.green[600],
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          Container(
                            margin: EdgeInsets.only(bottom: 20),
                            child: Text(
                              '$plantInformation',
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.black54,
                                fontWeight: FontWeight.normal,
                              ),
                              textAlign: TextAlign.justify,
                            ),
                          ),
                        ],
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 30),
                        color: Colors.green[900],
                        width: double.infinity,
                        height: MediaQuery.of(context).size.height /
                            16, //نجيب ارتفاع الجهاز
                        child: TextButton(
                          onPressed: () {
                            // var result = weight / (pow(heightVal / 100, 2));
                            // Navigator.push(context, MaterialPageRoute(builder: (context) {
                            //   return Result(result: result, isMale: isMale, age: age);
                          },
                          child: Text(
                            'Add to cart',
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
