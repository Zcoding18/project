import 'package:app/screens/info_palant_screen.dart';
import 'package:flutter/material.dart';

import 'screens/categories_screen.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'flutter Demo',
      theme: ThemeData(
        primaryColor: Colors.pink,
        canvasColor: Color.fromRGBO(255, 254, 229, 1),
        textTheme: const TextTheme(
          bodyText1: TextStyle(color: Colors.black),
          bodyText2: TextStyle(color: Colors.black),
          headline1: TextStyle(fontSize: 24),
        ),
      ),
      //home: CategoriesScreen(),
      routes: {
        '/': (context) => CategoriesScreen(),
        InfoPlantScrren.routeinfoplant: (context) => InfoPlantScrren(),
        //'/CategoryMealScrean': (context) => CategoryMeallScreen(),
      },
    );
  }
}
